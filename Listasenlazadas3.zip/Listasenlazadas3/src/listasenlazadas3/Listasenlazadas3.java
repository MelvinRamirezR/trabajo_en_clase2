
package listasenlazadas3;


import ico.fes.unam.LinkedListADT;
public class Listasenlazadas3 {


    public static void main(String[] args) {
       
        LinkedListADT lsl = new LinkedListADT();
        lsl.append(new String ("jose"));
         lsl.append(new String ("Diana"));
          lsl.append(new String ("Santiago"));
           lsl.append(new String ("Daniela"));
    lsl.Transversal();
    }
    
}
